
Janaki — Enhanced 20-page Birthday Website
-----------------------------------------
Instructions:
1. Extract the folder and open index.html in your browser to preview locally.
2. To publish, use Netlify Drop (https://app.netlify.com/drop) or GitHub Pages.
3. If images don't appear, ensure Google Drive images are "Anyone with the link can view".
4. To embed local images instead of Drive, put images in an 'images/' folder and update img src paths.
